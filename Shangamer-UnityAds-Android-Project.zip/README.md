# Shangamer - Unity Ads Native Android App

## Tech Stack
- **Target SDK**: 34, **Min SDK**: 24
- **Language**: Kotlin 1.9.23 + Jetpack Compose (Material 3)
- **Unity Ads SDK**: EXACTLY `4.21.0` (from `mavenCentral()`)
- **Persistence**: Jetpack DataStore Preferences
- **Telemetry**: OkHttp (Live https://ipwho.is/ query)
- **Game ID**: 800408340
- **Package Name**: com.Shangamer

## How to Run in Android Studio
1. Open Android Studio (Iguana, Jellyfish, Koala or newer).
2. Choose **File > Open...** and select this extracted directory.
3. Allow Gradle to sync.
4. Select a physical Android device or emulator.
5. Click **Run > Run 'app'** or **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
