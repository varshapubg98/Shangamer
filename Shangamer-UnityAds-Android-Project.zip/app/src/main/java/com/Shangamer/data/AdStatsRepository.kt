package com.Shangamer.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "shangamer_ad_stats")

class AdStatsRepository(private val context: Context) {

    private object PreferencesKeys {
        val COINS_BALANCE = intPreferencesKey("coins_balance")
        val TOTAL_COINS_EARNED = intPreferencesKey("total_coins_earned")
        val TOTAL_AD_CLICKS = intPreferencesKey("total_ad_clicks")
        val REWARDED_WATCHED = intPreferencesKey("rewarded_watched")
        val INTERSTITIALS_SHOWN = intPreferencesKey("interstitials_shown")
        val ADS_SKIPPED = intPreferencesKey("ads_skipped")
        val LOAD_SUCCESS = intPreferencesKey("load_success")
        val LOAD_FAILED = intPreferencesKey("load_failed")
    }

    val statsFlow: Flow<AdStats> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            AdStats(
                coinsBalance = preferences[PreferencesKeys.COINS_BALANCE] ?: 0,
                totalCoinsEarned = preferences[PreferencesKeys.TOTAL_COINS_EARNED] ?: 0,
                totalAdClicks = preferences[PreferencesKeys.TOTAL_AD_CLICKS] ?: 0,
                rewardedWatched = preferences[PreferencesKeys.REWARDED_WATCHED] ?: 0,
                interstitialsShown = preferences[PreferencesKeys.INTERSTITIALS_SHOWN] ?: 0,
                adsSkipped = preferences[PreferencesKeys.ADS_SKIPPED] ?: 0,
                loadSuccess = preferences[PreferencesKeys.LOAD_SUCCESS] ?: 0,
                loadFailed = preferences[PreferencesKeys.LOAD_FAILED] ?: 0
            )
        }

    suspend fun recordRewardedCompleted(coinsReward: Int) {
        context.dataStore.edit { preferences ->
            val currentCoins = preferences[PreferencesKeys.COINS_BALANCE] ?: 0
            val totalEarned = preferences[PreferencesKeys.TOTAL_COINS_EARNED] ?: 0
            val rewardedCount = preferences[PreferencesKeys.REWARDED_WATCHED] ?: 0

            preferences[PreferencesKeys.COINS_BALANCE] = currentCoins + coinsReward
            preferences[PreferencesKeys.TOTAL_COINS_EARNED] = totalEarned + coinsReward
            preferences[PreferencesKeys.REWARDED_WATCHED] = rewardedCount + 1
        }
    }

    suspend fun recordRewardedSkipped() {
        context.dataStore.edit { preferences ->
            val currentSkipped = preferences[PreferencesKeys.ADS_SKIPPED] ?: 0
            preferences[PreferencesKeys.ADS_SKIPPED] = currentSkipped + 1
        }
    }

    suspend fun recordInterstitialShown() {
        context.dataStore.edit { preferences ->
            val currentInterstitials = preferences[PreferencesKeys.INTERSTITIALS_SHOWN] ?: 0
            preferences[PreferencesKeys.INTERSTITIALS_SHOWN] = currentInterstitials + 1
        }
    }

    suspend fun recordAdClicked() {
        context.dataStore.edit { preferences ->
            val currentClicks = preferences[PreferencesKeys.TOTAL_AD_CLICKS] ?: 0
            preferences[PreferencesKeys.TOTAL_AD_CLICKS] = currentClicks + 1
        }
    }

    suspend fun recordLoadSuccess() {
        context.dataStore.edit { preferences ->
            val currentSuccess = preferences[PreferencesKeys.LOAD_SUCCESS] ?: 0
            preferences[PreferencesKeys.LOAD_SUCCESS] = currentSuccess + 1
        }
    }

    suspend fun recordLoadFailed() {
        context.dataStore.edit { preferences ->
            val currentFailed = preferences[PreferencesKeys.LOAD_FAILED] ?: 0
            preferences[PreferencesKeys.LOAD_FAILED] = currentFailed + 1
        }
    }

    suspend fun resetStats() {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.COINS_BALANCE] = 0
            preferences[PreferencesKeys.TOTAL_COINS_EARNED] = 0
            preferences[PreferencesKeys.TOTAL_AD_CLICKS] = 0
            preferences[PreferencesKeys.REWARDED_WATCHED] = 0
            preferences[PreferencesKeys.INTERSTITIALS_SHOWN] = 0
            preferences[PreferencesKeys.ADS_SKIPPED] = 0
            preferences[PreferencesKeys.LOAD_SUCCESS] = 0
            preferences[PreferencesKeys.LOAD_FAILED] = 0
        }
    }
}
