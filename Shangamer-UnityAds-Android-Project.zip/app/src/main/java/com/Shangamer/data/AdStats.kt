package com.Shangamer.data

data class AdStats(
    val coinsBalance: Int = 0,
    val totalCoinsEarned: Int = 0,
    val totalAdClicks: Int = 0,
    val rewardedWatched: Int = 0,
    val interstitialsShown: Int = 0,
    val adsSkipped: Int = 0,
    val loadSuccess: Int = 0,
    val loadFailed: Int = 0
) {
    val totalAdsShown: Int
        get() = rewardedWatched + interstitialsShown

    val ctrPercentage: Double
        get() = if (totalAdsShown > 0) {
            (totalAdClicks.toDouble() / totalAdsShown.toDouble()) * 100.0
        } else {
            0.0
        }

    val estimatedEarningsUsd: Double
        get() = (totalAdsShown.toDouble() / 1000.0) * com.Shangamer.Constants.ESTIMATED_ECPM_USD
}
