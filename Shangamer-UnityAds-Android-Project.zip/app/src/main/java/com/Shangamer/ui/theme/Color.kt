package com.Shangamer.ui.theme

import androidx.compose.ui.graphics.Color

val DarkPurpleBg = Color(0xFF0F0B1E)
val DarkNavyBg = Color(0xFF060914)
val SurfaceCard = Color(0x1AFFFFFF)
val SurfaceCardBorder = Color(0x26FFFFFF)

val AccentPurple = Color(0xFF8B5CF6)
val AccentPurpleLight = Color(0xFFA78BFA)
val AccentEmerald = Color(0xFF10B981)
val AccentAmber = Color(0xFFF59E0B)
val AccentRose = Color(0xFFF43F5E)
val AccentSky = Color(0xFF0EA5E9)

val GoldCoinYellow = Color(0xFFFBBF24)
val GoldCoinOrange = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
