package com.Shangamer.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Shangamer.ui.theme.AccentEmerald
import com.Shangamer.ui.theme.GoldCoinYellow
import com.Shangamer.ui.theme.TextPrimary

@Composable
fun AdActionButtons(
    isRewardedPending: Boolean,
    isInterstitialPending: Boolean,
    onWatchRewardedClick: () -> Unit,
    onShowInterstitialClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Infinite transition for gentle pulsing glow and shimmer
    val infiniteTransition = rememberInfiniteTransition(label = "ButtonsAnimation")

    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseGlow"
    )

    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = -300f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ShimmerOffset"
    )

    // Gift icon wiggle (rotation between -10 and +10 deg)
    val giftWiggle by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GiftWiggle"
    )

    // TV icon bounce (translationY between 0 and -5dp)
    val tvBounce by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -5f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "TvBounce"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Rewarded Ad Button
        InteractiveAdButton(
            title = if (isRewardedPending) "Loading ad..." else "Watch Rewarded Ad (+10 Coins)",
            subtitle = if (isRewardedPending) "Waiting up to 30s..." else "Full screen reward • 100% verified",
            icon = Icons.Default.CardGiftcard,
            iconTint = GoldCoinYellow,
            iconRotation = giftWiggle,
            iconTranslationY = 0f,
            isLoading = isRewardedPending,
            pulseAlpha = pulseGlow,
            shimmerOffset = shimmerOffset,
            gradientColors = listOf(Color(0xFF7C3AED), Color(0xFF6D28D9), Color(0xFF4C1D95)),
            glowColor = Color(0xFF8B5CF6),
            onClick = onWatchRewardedClick
        )

        // Interstitial Ad Button
        InteractiveAdButton(
            title = if (isInterstitialPending) "Loading ad..." else "Show Interstitial Ad",
            subtitle = if (isInterstitialPending) "Waiting up to 30s..." else "High impact interstitial display",
            icon = Icons.Default.Tv,
            iconTint = Color(0xFF38BDF8),
            iconRotation = 0f,
            iconTranslationY = tvBounce,
            isLoading = isInterstitialPending,
            pulseAlpha = pulseGlow,
            shimmerOffset = shimmerOffset,
            gradientColors = listOf(Color(0xFF0284C7), Color(0xFF0369A1), Color(0xFF1E3A8A)),
            glowColor = Color(0xFF0284C7),
            onClick = onShowInterstitialClick
        )
    }
}

@Composable
private fun InteractiveAdButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    iconRotation: Float,
    iconTranslationY: Float,
    isLoading: Boolean,
    pulseAlpha: Float,
    shimmerOffset: Float,
    gradientColors: List<Color>,
    glowColor: Color,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Spring bounce scale down to 0.94 on tap
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "ButtonSpringScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = (12 * pulseAlpha).dp,
                shape = RoundedCornerShape(18.dp),
                ambientColor = glowColor.copy(alpha = 0.5f),
                spotColor = glowColor
            )
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.linearGradient(
                    colors = gradientColors,
                    start = Offset(0f, 0f),
                    end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.5f),
                        glowColor.copy(alpha = pulseAlpha),
                        Color.White.copy(alpha = 0.2f)
                    )
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(vertical = 16.dp, horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Animated Icon or loading indicator
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(28.dp),
                        color = Color.White,
                        strokeWidth = 3.dp
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .graphicsLayer {
                                rotationZ = iconRotation
                                translationY = iconTranslationY
                            }
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = iconTint,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.3.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        color = Color(0xFFE2E8F0).copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Always active badge indicator
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.35f))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (isLoading) "WAIT" else "READY",
                    color = if (isLoading) Color(0xFFFBBF24) else AccentEmerald,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}
