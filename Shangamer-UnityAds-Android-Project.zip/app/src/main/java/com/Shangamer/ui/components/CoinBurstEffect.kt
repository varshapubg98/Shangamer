package com.Shangamer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.Shangamer.ui.theme.GoldCoinOrange
import com.Shangamer.ui.theme.GoldCoinYellow
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class Particle(
    val angle: Double,
    val speed: Float,
    val radius: Float,
    val color: Color
)

@Composable
fun CoinBurstEffect(
    modifier: Modifier = Modifier,
    onFinished: () -> Unit = {}
) {
    val progress = remember { Animatable(0f) }

    val particles = remember {
        val colors = listOf(
            GoldCoinYellow,
            GoldCoinOrange,
            Color(0xFFFEF08A),
            Color(0xFFFDE047),
            Color(0xFFF59E0B)
        )
        List(32) {
            Particle(
                angle = Random.nextDouble(0.0, 2.0 * Math.PI),
                speed = Random.nextFloat() * 320f + 160f,
                radius = Random.nextFloat() * 6f + 4f,
                color = colors[Random.nextInt(colors.size)]
            )
        }
    }

    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 900, easing = FastOutLinearInEasing)
        )
        onFinished()
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 3f)
        val p = progress.value
        val alpha = (1f - p).coerceIn(0f, 1f)

        particles.forEach { particle ->
            val distance = particle.speed * p
            val x = center.x + (cos(particle.angle) * distance).toFloat()
            val y = center.y + (sin(particle.angle) * distance).toFloat() + (p * p * 120f)

            drawCircle(
                color = particle.color.copy(alpha = alpha),
                radius = particle.radius * (1f - p * 0.4f),
                center = Offset(x, y)
            )
        }
    }
}
