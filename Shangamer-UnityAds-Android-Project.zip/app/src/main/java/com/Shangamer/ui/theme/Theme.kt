package com.Shangamer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = AccentPurple,
    onPrimary = TextPrimary,
    secondary = AccentSky,
    tertiary = GoldCoinYellow,
    background = DarkPurpleBg,
    surface = SurfaceCard,
    onSurface = TextPrimary
)

@Composable
fun ShangamerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
