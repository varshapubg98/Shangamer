package com.Shangamer.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Shangamer.data.AdStats
import com.Shangamer.ui.theme.AccentEmerald
import com.Shangamer.ui.theme.AccentPurple
import com.Shangamer.ui.theme.AccentRose
import com.Shangamer.ui.theme.AccentSky
import com.Shangamer.ui.theme.GoldCoinYellow
import com.Shangamer.ui.theme.TextMuted
import com.Shangamer.ui.theme.TextPrimary
import com.Shangamer.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun AdPerformanceCard(
    stats: AdStats,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF191236).copy(alpha = 0.75f), Color(0xFF0F0B1E).copy(alpha = 0.85f))
                )
            )
            .border(1.dp, Color(0x33A855F7), RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Ad Performance & Analytics",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real counters persisted in DataStore",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x338B5CF6))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "DataStore Active",
                        color = AccentPurple,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2-Column Grid of tiles
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Row 1: Clicks & CTR%
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        label = "Total Ad Clicks",
                        count = stats.totalAdClicks,
                        icon = Icons.Default.TouchApp,
                        iconTint = AccentSky,
                        gradient = listOf(Color(0xFF0284C7).copy(alpha = 0.25f), Color(0xFF0C4A6E).copy(alpha = 0.15f)),
                        modifier = Modifier.weight(1f)
                    )
                    FormattedMetricTile(
                        label = "CTR %",
                        formattedValue = String.format(Locale.US, "%.1f%%", stats.ctrPercentage),
                        subtitle = "${stats.totalAdClicks} / ${stats.totalAdsShown} ads",
                        icon = Icons.Default.Percent,
                        iconTint = AccentEmerald,
                        gradient = listOf(Color(0xFF059669).copy(alpha = 0.25f), Color(0xFF064E3B).copy(alpha = 0.15f)),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 2: Rewarded Watched & Interstitials Shown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        label = "Rewarded Watched",
                        count = stats.rewardedWatched,
                        icon = Icons.Default.VideoLibrary,
                        iconTint = AccentPurple,
                        gradient = listOf(Color(0xFF7C3AED).copy(alpha = 0.25f), Color(0xFF4C1D95).copy(alpha = 0.15f)),
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "Interstitials Shown",
                        count = stats.interstitialsShown,
                        icon = Icons.Default.Tv,
                        iconTint = Color(0xFF38BDF8),
                        gradient = listOf(Color(0xFF0284C7).copy(alpha = 0.25f), Color(0xFF1E3A8A).copy(alpha = 0.15f)),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 3: Ads Skipped & Total Coins Earned
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        label = "Ads Skipped",
                        count = stats.adsSkipped,
                        icon = Icons.Default.SkipNext,
                        iconTint = Color(0xFFF97316),
                        gradient = listOf(Color(0xFFEA580C).copy(alpha = 0.25f), Color(0xFF7C2D12).copy(alpha = 0.15f)),
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "Total Coins Earned",
                        count = stats.totalCoinsEarned,
                        icon = Icons.Default.MonetizationOn,
                        iconTint = GoldCoinYellow,
                        gradient = listOf(Color(0xFFD97706).copy(alpha = 0.25f), Color(0xFF78350F).copy(alpha = 0.15f)),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 4: Load Success & Load Failed
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        label = "Load Success",
                        count = stats.loadSuccess,
                        icon = Icons.Default.CheckCircle,
                        iconTint = AccentEmerald,
                        gradient = listOf(Color(0xFF10B981).copy(alpha = 0.2f), Color(0xFF064E3B).copy(alpha = 0.15f)),
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(
                        label = "Load Failed",
                        count = stats.loadFailed,
                        icon = Icons.Default.Error,
                        iconTint = AccentRose,
                        gradient = listOf(Color(0xFFE11D48).copy(alpha = 0.2f), Color(0xFF881337).copy(alpha = 0.15f)),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Estimated Earnings Tile
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF065F46).copy(alpha = 0.4f), Color(0xFF047857).copy(alpha = 0.2f))
                            )
                        )
                        .border(1.dp, AccentEmerald.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AccentEmerald.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AttachMoney,
                                    contentDescription = "Earnings",
                                    tint = AccentEmerald,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Estimated Earnings",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Estimated (check Unity Dashboard for real earnings)",
                                    color = Color(0xFFA7F3D0),
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Text(
                            text = String.format(Locale.US, "$%.4f", stats.estimatedEarningsUsd),
                            color = AccentEmerald,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricTile(
    label: String,
    count: Int,
    icon: ImageVector,
    iconTint: Color,
    gradient: List<Color>,
    modifier: Modifier = Modifier
) {
    val animatedCount by animateIntAsState(
        targetValue = count,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "MetricTileCount"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(gradient))
            .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = label,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconTint,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "$animatedCount",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun FormattedMetricTile(
    label: String,
    formattedValue: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    gradient: List<Color>,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(gradient))
            .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = label,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconTint,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formattedValue,
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = TextMuted,
                    fontSize = 9.sp
                )
            }
        }
    }
}
