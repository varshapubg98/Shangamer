package com.Shangamer.ui

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.Shangamer.ads.AdLoadingStatus
import com.Shangamer.ads.SdkInitStatus
import com.Shangamer.ads.UiEvent
import com.Shangamer.ads.UnityAdsManager
import com.Shangamer.data.AdStats
import com.Shangamer.data.AdStatsRepository
import com.Shangamer.network.NetworkLocationService
import com.Shangamer.network.NetworkLocationState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AdStatsRepository(application.applicationContext)
    private val locationService = NetworkLocationService()
    val adsManager = UnityAdsManager(
        context = application.applicationContext,
        repository = repository,
        coroutineScope = viewModelScope
    )

    // Stats from DataStore
    val adStats: StateFlow<AdStats> = repository.statsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AdStats()
        )

    // Network & Geolocation state
    private val _networkLocationState = MutableStateFlow<NetworkLocationState>(NetworkLocationState.Loading)
    val networkLocationState: StateFlow<NetworkLocationState> = _networkLocationState.asStateFlow()

    // Live session timer in seconds
    private val _sessionDurationSeconds = MutableStateFlow(0L)
    val sessionDurationSeconds: StateFlow<Long> = _sessionDurationSeconds.asStateFlow()

    // Ads status delegated from manager
    val sdkStatus: StateFlow<SdkInitStatus> = adsManager.sdkStatus
    val rewardedStatus: StateFlow<AdLoadingStatus> = adsManager.rewardedStatus
    val interstitialStatus: StateFlow<AdLoadingStatus> = adsManager.interstitialStatus
    val rawErrorMessage: StateFlow<String?> = adsManager.rawErrorMessage
    val isRewardedPending: StateFlow<Boolean> = adsManager.isRewardedPending
    val isInterstitialPending: StateFlow<Boolean> = adsManager.isInterstitialPending
    val uiEvents = adsManager.uiEvents

    init {
        fetchLocation()
        startSessionTimer()
    }

    fun fetchLocation() {
        viewModelScope.launch {
            _networkLocationState.value = NetworkLocationState.Loading
            _networkLocationState.value = locationService.fetchLocation()
        }
    }

    private fun startSessionTimer() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000)
                _sessionDurationSeconds.value += 1
            }
        }
    }

    fun showRewardedAd(activity: Activity) {
        adsManager.showRewardedAd(activity)
    }

    fun showInterstitialAd(activity: Activity) {
        adsManager.showInterstitialAd(activity)
    }

    fun reloadAds() {
        adsManager.reloadAllAds()
    }

    fun resetAllStats() {
        viewModelScope.launch {
            repository.resetStats()
        }
    }
}
