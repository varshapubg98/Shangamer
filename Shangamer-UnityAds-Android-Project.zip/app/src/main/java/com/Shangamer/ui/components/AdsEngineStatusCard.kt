package com.Shangamer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Shangamer.ads.AdLoadingStatus
import com.Shangamer.ads.SdkInitStatus
import com.Shangamer.ui.theme.AccentEmerald
import com.Shangamer.ui.theme.AccentPurple
import com.Shangamer.ui.theme.AccentRose
import com.Shangamer.ui.theme.AccentSky
import com.Shangamer.ui.theme.TextMuted
import com.Shangamer.ui.theme.TextPrimary
import com.Shangamer.ui.theme.TextSecondary

@Composable
fun AdsEngineStatusCard(
    sdkStatus: SdkInitStatus,
    rewardedStatus: AdLoadingStatus,
    interstitialStatus: AdLoadingStatus,
    rawErrorMessage: String?,
    onReloadAds: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1E1738).copy(alpha = 0.7f), Color(0xFF120F26).copy(alpha = 0.8f))
                )
            )
            .border(1.dp, Color(0x338B5CF6), RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Ads Engine Status",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Unity v4.21.0 Direct Engine",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                OutlinedButton(
                    onClick = onReloadAds,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color(0x1A8B5CF6),
                        contentColor = TextPrimary
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = Brush.horizontalGradient(listOf(AccentPurple, AccentSky))
                    ),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reload Ads",
                        tint = AccentSky,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Reload Ads", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Status items with colored indicator dots
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatusIndicatorItem(
                    label = "SDK Status",
                    statusText = when (sdkStatus) {
                        is SdkInitStatus.Initialized -> "Initialized"
                        is SdkInitStatus.Initializing -> "Initializing..."
                        is SdkInitStatus.Failed -> "Failed"
                        SdkInitStatus.NotInitialized -> "Idle"
                    },
                    statusColor = when (sdkStatus) {
                        is SdkInitStatus.Initialized -> AccentEmerald
                        is SdkInitStatus.Initializing -> Color(0xFFFBBF24)
                        is SdkInitStatus.Failed -> AccentRose
                        SdkInitStatus.NotInitialized -> TextMuted
                    }
                )

                StatusIndicatorItem(
                    label = "Rewarded",
                    statusText = when (rewardedStatus) {
                        is AdLoadingStatus.Ready -> "Ready"
                        is AdLoadingStatus.Loading -> "Loading"
                        is AdLoadingStatus.Error -> "Failed"
                        AdLoadingStatus.Idle -> "Idle"
                    },
                    statusColor = when (rewardedStatus) {
                        is AdLoadingStatus.Ready -> AccentEmerald
                        is AdLoadingStatus.Loading -> Color(0xFFFBBF24)
                        is AdLoadingStatus.Error -> AccentRose
                        AdLoadingStatus.Idle -> TextMuted
                    }
                )

                StatusIndicatorItem(
                    label = "Interstitial",
                    statusText = when (interstitialStatus) {
                        is AdLoadingStatus.Ready -> "Ready"
                        is AdLoadingStatus.Loading -> "Loading"
                        is AdLoadingStatus.Error -> "Failed"
                        AdLoadingStatus.Idle -> "Idle"
                    },
                    statusColor = when (interstitialStatus) {
                        is AdLoadingStatus.Ready -> AccentEmerald
                        is AdLoadingStatus.Loading -> Color(0xFFFBBF24)
                        is AdLoadingStatus.Error -> AccentRose
                        AdLoadingStatus.Idle -> TextMuted
                    }
                )
            }

            // Raw Unity error box if any error occurs
            if (!rawErrorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF2A1015))
                        .border(1.dp, AccentRose.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Error",
                            tint = AccentRose,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "RAW UNITY SDK ERROR:",
                                color = AccentRose,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = rawErrorMessage,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusIndicatorItem(
    label: String,
    statusText: String,
    statusColor: Color
) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(statusColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = statusText,
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
