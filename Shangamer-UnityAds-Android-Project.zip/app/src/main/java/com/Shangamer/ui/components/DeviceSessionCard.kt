package com.Shangamer.ui.components

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Shangamer.Constants
import com.Shangamer.ads.SdkInitStatus
import com.Shangamer.ui.theme.AccentEmerald
import com.Shangamer.ui.theme.AccentPurple
import com.Shangamer.ui.theme.AccentRose
import com.Shangamer.ui.theme.AccentSky
import com.Shangamer.ui.theme.TextMuted
import com.Shangamer.ui.theme.TextPrimary
import com.Shangamer.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun DeviceSessionCard(
    sessionSeconds: Long,
    sdkStatus: SdkInitStatus,
    onResetStatsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val minutes = sessionSeconds / 60
    val seconds = sessionSeconds % 60
    val formattedTime = String.format(Locale.US, "%02d:%02d", minutes, seconds)

    val deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
    val androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF14132B).copy(alpha = 0.75f), Color(0xFF0D0E1C).copy(alpha = 0.85f))
                )
            )
            .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Devices,
                        contentDescription = "Device info",
                        tint = AccentSky,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Device & Live Session",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Mode Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (Constants.TEST_MODE) Color(0x33F59E0B) else Color(0x3310B981))
                        .border(
                            1.dp,
                            if (Constants.TEST_MODE) Color(0xFFF59E0B) else AccentEmerald,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (Constants.TEST_MODE) "TEST MODE" else "PRODUCTION MODE",
                        color = if (Constants.TEST_MODE) Color(0xFFFBBF24) else AccentEmerald,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Details list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DetailRow(label = "Hardware Model", value = deviceModel)
                DetailRow(label = "Operating System", value = androidVersion)
                DetailRow(label = "Application Version", value = "v1.0.0 (Release)")
                DetailRow(
                    label = "SDK Status",
                    value = when (sdkStatus) {
                        is SdkInitStatus.Initialized -> "Initialized"
                        is SdkInitStatus.Initializing -> "Initializing"
                        is SdkInitStatus.Failed -> "Failed"
                        SdkInitStatus.NotInitialized -> "Uninitialized"
                    }
                )
                DetailRow(label = "Live Session Duration", value = formattedTime, isHighlight = true)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Reset Stats Button
            OutlinedButton(
                onClick = onResetStatsClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color(0x1AF43F5E),
                    contentColor = AccentRose
                ),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.horizontalGradient(listOf(AccentRose, Color(0xFFFB7185)))
                )
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Reset Stats",
                    tint = AccentRose,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Reset All Telemetry & Ad Stats",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Text(
            text = value,
            color = if (isHighlight) AccentSky else TextPrimary,
            fontSize = 12.sp,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.SemiBold,
            fontFamily = if (isHighlight) FontFamily.Monospace else FontFamily.Default
        )
    }
}
