package com.Shangamer.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class NetworkLocationData(
    val ip: String = "",
    val country: String = "",
    val countryCode: String = "",
    val region: String = "",
    val city: String = "",
    val isp: String = "",
    val timezone: String = "",
    val flagEmoji: String = "🌐"
)

sealed class NetworkLocationState {
    object Loading : NetworkLocationState()
    data class Success(val data: NetworkLocationData) : NetworkLocationState()
    data class Error(val message: String) : NetworkLocationState()
}

class NetworkLocationService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun fetchLocation(): NetworkLocationState = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("https://ipwho.is/")
            .header("User-Agent", "Shangamer-Android-Telemetry/1.0")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext NetworkLocationState.Error("HTTP error: ${response.code}")
                }

                val body = response.body?.string()
                    ?: return@withContext NetworkLocationState.Error("Empty response body")

                val json = JSONObject(body)
                val success = json.optBoolean("success", false)

                if (!success) {
                    val message = json.optString("message", "Failed to retrieve location")
                    return@withContext NetworkLocationState.Error(message)
                }

                val ip = json.optString("ip", "Unknown IP")
                val country = json.optString("country", "Unknown Country")
                val countryCode = json.optString("country_code", "")
                val region = json.optString("region", "Unknown Region")
                val city = json.optString("city", "Unknown City")

                val connectionObj = json.optJSONObject("connection")
                val isp = connectionObj?.optString("isp") ?: json.optString("isp", "Unknown ISP")

                val timezoneObj = json.optJSONObject("timezone")
                val timezone = timezoneObj?.optString("id") ?: json.optString("timezone", "UTC")

                val flagObj = json.optJSONObject("flag")
                val flagEmoji = flagObj?.optString("emoji") ?: getFlagEmojiFromCountryCode(countryCode)

                NetworkLocationState.Success(
                    NetworkLocationData(
                        ip = ip,
                        country = country,
                        countryCode = countryCode,
                        region = region,
                        city = city,
                        isp = isp,
                        timezone = timezone,
                        flagEmoji = flagEmoji
                    )
                )
            }
        } catch (e: IOException) {
            NetworkLocationState.Error("Network error: ${e.localizedMessage ?: "Connection timed out"}")
        } catch (e: Exception) {
            NetworkLocationState.Error("Parse error: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    private fun getFlagEmojiFromCountryCode(countryCode: String): String {
        if (countryCode.length != 2) return "🌐"
        val firstChar = Character.codePointAt(countryCode.uppercase(), 0) - 0x41 + 0x1F1E6
        val secondChar = Character.codePointAt(countryCode.uppercase(), 1) - 0x41 + 0x1F1E6
        return String(Character.toChars(firstChar)) + String(Character.toChars(secondChar))
    }
}
