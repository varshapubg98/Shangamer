package com.Shangamer

object Constants {
    const val APP_NAME = "Shangamer"
    const val PACKAGE_NAME = "com.Shangamer"
    const val UNITY_GAME_ID = "800408340"
    const val REWARDED_PLACEMENT_ID = "REWARDED_ID"
    const val INTERSTITIAL_PLACEMENT_ID = "InterINTERSTITIAL_ID"
    const val TEST_MODE = false
    const val ESTIMATED_ECPM_USD = 2.0
    const val REWARD_COINS_PER_AD = 10
    const val UNITY_SDK_VERSION = "4.21.0"
}
