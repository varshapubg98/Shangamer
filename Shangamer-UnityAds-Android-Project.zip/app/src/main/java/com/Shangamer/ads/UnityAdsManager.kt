package com.Shangamer.ads

import android.app.Activity
import android.content.Context
import com.Shangamer.Constants
import com.Shangamer.data.AdStatsRepository
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AdLoadingStatus {
    object Idle : AdLoadingStatus()
    object Loading : AdLoadingStatus()
    object Ready : AdLoadingStatus()
    data class Error(val code: String, val rawMessage: String) : AdLoadingStatus()
}

sealed class SdkInitStatus {
    object NotInitialized : SdkInitStatus()
    object Initializing : SdkInitStatus()
    object Initialized : SdkInitStatus()
    data class Failed(val code: String, val rawMessage: String) : SdkInitStatus()
}

sealed class UiEvent {
    data class ShowToast(val message: String) : UiEvent()
    data class ShowRewardSnackbar(val coins: Int, val message: String) : UiEvent()
    object TriggerCoinConfetti : UiEvent()
}

class UnityAdsManager(
    private val context: Context,
    private val repository: AdStatsRepository,
    private val coroutineScope: CoroutineScope
) {

    private val _sdkStatus = MutableStateFlow<SdkInitStatus>(SdkInitStatus.NotInitialized)
    val sdkStatus: StateFlow<SdkInitStatus> = _sdkStatus.asStateFlow()

    private val _rewardedStatus = MutableStateFlow<AdLoadingStatus>(AdLoadingStatus.Idle)
    val rewardedStatus: StateFlow<AdLoadingStatus> = _rewardedStatus.asStateFlow()

    private val _interstitialStatus = MutableStateFlow<AdLoadingStatus>(AdLoadingStatus.Idle)
    val interstitialStatus: StateFlow<AdLoadingStatus> = _interstitialStatus.asStateFlow()

    private val _rawErrorMessage = MutableStateFlow<String?>(null)
    val rawErrorMessage: StateFlow<String?> = _rawErrorMessage.asStateFlow()

    private val _uiEvents = MutableSharedFlow<UiEvent>()
    val uiEvents: SharedFlow<UiEvent> = _uiEvents.asSharedFlow()

    // Pending auto-show request while button is waiting up to 30 seconds
    private var pendingRewardedJob: Job? = null
    private var pendingInterstitialJob: Job? = null

    private val _isRewardedPending = MutableStateFlow(false)
    val isRewardedPending: StateFlow<Boolean> = _isRewardedPending.asStateFlow()

    private val _isInterstitialPending = MutableStateFlow(false)
    val isInterstitialPending: StateFlow<Boolean> = _isInterstitialPending.asStateFlow()

    private var retryRewardedJob: Job? = null
    private var retryInterstitialJob: Job? = null

    init {
        initializeSdk()
    }

    fun initializeSdk() {
        if (_sdkStatus.value is SdkInitStatus.Initializing || _sdkStatus.value is SdkInitStatus.Initialized) {
            return
        }

        _sdkStatus.value = SdkInitStatus.Initializing

        // Initialize strictly using standard method without extra bidding frameworks
        UnityAds.initialize(
            context.applicationContext,
            Constants.UNITY_GAME_ID,
            Constants.TEST_MODE,
            object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() {
                    _sdkStatus.value = SdkInitStatus.Initialized
                    _rawErrorMessage.value = null
                    // Auto-load both Rewarded and Interstitial ads upon initialization
                    loadRewardedAd()
                    loadInterstitialAd()
                }

                override fun onInitializationFailed(
                    error: UnityAds.UnityAdsInitializationError?,
                    message: String?
                ) {
                    val codeStr = error?.name ?: "UNKNOWN_INIT_ERROR"
                    val msgStr = message ?: "Unity Ads SDK initialization failed"
                    _sdkStatus.value = SdkInitStatus.Failed(codeStr, msgStr)
                    _rawErrorMessage.value = "Init Failed [$codeStr]: $msgStr"
                }
            }
        )
    }

    fun reloadAllAds() {
        if (_sdkStatus.value !is SdkInitStatus.Initialized) {
            initializeSdk()
        } else {
            loadRewardedAd()
            loadInterstitialAd()
        }
    }

    // ==========================================
    // REWARDED AD LOADING & DISPLAY
    // ==========================================

    fun loadRewardedAd() {
        if (_rewardedStatus.value is AdLoadingStatus.Loading) return
        _rewardedStatus.value = AdLoadingStatus.Loading

        UnityAds.load(Constants.REWARDED_PLACEMENT_ID, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) {
                _rewardedStatus.value = AdLoadingStatus.Ready
                _rawErrorMessage.value = null
                coroutineScope.launch {
                    repository.recordLoadSuccess()
                }
            }

            override fun onUnityAdsFailedToLoad(
                placementId: String?,
                error: UnityAds.UnityAdsLoadError?,
                message: String?
            ) {
                val code = error?.name ?: "LOAD_ERROR"
                val rawMsg = message ?: "Rewarded ad failed to load"
                _rewardedStatus.value = AdLoadingStatus.Error(code, rawMsg)
                _rawErrorMessage.value = "Rewarded Load Error [$code]: $rawMsg"

                coroutineScope.launch {
                    repository.recordLoadFailed()
                }

                // Retry silently after 5 seconds
                scheduleRetry(isRewarded = true)
            }
        })
    }

    fun showRewardedAd(activity: Activity) {
        // Prevent concurrent triggers while pending
        if (_isRewardedPending.value) return

        if (_rewardedStatus.value is AdLoadingStatus.Ready) {
            executeShowRewarded(activity)
            return
        }

        // Ad is still loading: start pending wait (up to 30s)
        _isRewardedPending.value = true
        loadRewardedAd()

        pendingRewardedJob?.cancel()
        pendingRewardedJob = coroutineScope.launch {
            val startTime = System.currentTimeMillis()
            var showed = false

            while (System.currentTimeMillis() - startTime < 30_000) {
                if (_rewardedStatus.value is AdLoadingStatus.Ready) {
                    executeShowRewarded(activity)
                    showed = true
                    break
                }
                delay(300)
            }

            _isRewardedPending.value = false
            if (!showed) {
                _uiEvents.emit(UiEvent.ShowToast("No ad available right now, please try again"))
            }
        }
    }

    private fun executeShowRewarded(activity: Activity) {
        _isRewardedPending.value = false
        pendingRewardedJob?.cancel()

        UnityAds.show(
            activity,
            Constants.REWARDED_PLACEMENT_ID,
            UnityAdsShowOptions(),
            object : IUnityAdsShowListener {
                override fun onUnityAdsShowStart(placementId: String?) {
                    // Ad started displaying
                }

                override fun onUnityAdsShowClick(placementId: String?) {
                    coroutineScope.launch {
                        repository.recordAdClicked()
                    }
                }

                override fun onUnityAdsShowComplete(
                    placementId: String?,
                    state: UnityAds.UnityAdsShowCompletionState?
                ) {
                    when (state) {
                        UnityAds.UnityAdsShowCompletionState.COMPLETED -> {
                            coroutineScope.launch {
                                repository.recordRewardedCompleted(Constants.REWARD_COINS_PER_AD)
                                _uiEvents.emit(
                                    UiEvent.ShowRewardSnackbar(
                                        Constants.REWARD_COINS_PER_AD,
                                        "Congratulations! You received +${Constants.REWARD_COINS_PER_AD} Coins!"
                                    )
                                )
                                _uiEvents.emit(UiEvent.TriggerCoinConfetti)
                            }
                        }
                        UnityAds.UnityAdsShowCompletionState.SKIPPED -> {
                            coroutineScope.launch {
                                repository.recordRewardedSkipped()
                                _uiEvents.emit(
                                    UiEvent.ShowToast("Ad was skipped. No coins rewarded.")
                                )
                            }
                        }
                        else -> {
                            // Other state
                        }
                    }
                    // Silently load next ad after display
                    _rewardedStatus.value = AdLoadingStatus.Idle
                    loadRewardedAd()
                }

                override fun onUnityAdsShowFailure(
                    placementId: String?,
                    error: UnityAds.UnityAdsShowError?,
                    message: String?
                ) {
                    val code = error?.name ?: "SHOW_ERROR"
                    val msg = message ?: "Failed to display Rewarded Ad"
                    _rawErrorMessage.value = "Rewarded Show Error [$code]: $msg"
                    coroutineScope.launch {
                        _uiEvents.emit(UiEvent.ShowToast("Ad failed to show: $msg"))
                    }
                    // Silently reload next ad
                    _rewardedStatus.value = AdLoadingStatus.Idle
                    loadRewardedAd()
                }
            }
        )
    }

    // ==========================================
    // INTERSTITIAL AD LOADING & DISPLAY
    // ==========================================

    fun loadInterstitialAd() {
        if (_interstitialStatus.value is AdLoadingStatus.Loading) return
        _interstitialStatus.value = AdLoadingStatus.Loading

        UnityAds.load(Constants.INTERSTITIAL_PLACEMENT_ID, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) {
                _interstitialStatus.value = AdLoadingStatus.Ready
                _rawErrorMessage.value = null
                coroutineScope.launch {
                    repository.recordLoadSuccess()
                }
            }

            override fun onUnityAdsFailedToLoad(
                placementId: String?,
                error: UnityAds.UnityAdsLoadError?,
                message: String?
            ) {
                val code = error?.name ?: "LOAD_ERROR"
                val rawMsg = message ?: "Interstitial ad failed to load"
                _interstitialStatus.value = AdLoadingStatus.Error(code, rawMsg)
                _rawErrorMessage.value = "Interstitial Load Error [$code]: $rawMsg"

                coroutineScope.launch {
                    repository.recordLoadFailed()
                }

                // Retry silently after 5 seconds
                scheduleRetry(isRewarded = false)
            }
        })
    }

    fun showInterstitialAd(activity: Activity) {
        // Prevent concurrent triggers while pending
        if (_isInterstitialPending.value) return

        if (_interstitialStatus.value is AdLoadingStatus.Ready) {
            executeShowInterstitial(activity)
            return
        }

        // Ad is still loading: start pending wait (up to 30s)
        _isInterstitialPending.value = true
        loadInterstitialAd()

        pendingInterstitialJob?.cancel()
        pendingInterstitialJob = coroutineScope.launch {
            val startTime = System.currentTimeMillis()
            var showed = false

            while (System.currentTimeMillis() - startTime < 30_000) {
                if (_interstitialStatus.value is AdLoadingStatus.Ready) {
                    executeShowInterstitial(activity)
                    showed = true
                    break
                }
                delay(300)
            }

            _isInterstitialPending.value = false
            if (!showed) {
                _uiEvents.emit(UiEvent.ShowToast("No ad available right now, please try again"))
            }
        }
    }

    private fun executeShowInterstitial(activity: Activity) {
        _isInterstitialPending.value = false
        pendingInterstitialJob?.cancel()

        UnityAds.show(
            activity,
            Constants.INTERSTITIAL_PLACEMENT_ID,
            UnityAdsShowOptions(),
            object : IUnityAdsShowListener {
                override fun onUnityAdsShowStart(placementId: String?) {
                    // Ad started
                }

                override fun onUnityAdsShowClick(placementId: String?) {
                    coroutineScope.launch {
                        repository.recordAdClicked()
                    }
                }

                override fun onUnityAdsShowComplete(
                    placementId: String?,
                    state: UnityAds.UnityAdsShowCompletionState?
                ) {
                    coroutineScope.launch {
                        if (state == UnityAds.UnityAdsShowCompletionState.SKIPPED) {
                            repository.recordRewardedSkipped()
                        } else {
                            repository.recordInterstitialShown()
                        }
                    }
                    // Silently reload next ad
                    _interstitialStatus.value = AdLoadingStatus.Idle
                    loadInterstitialAd()
                }

                override fun onUnityAdsShowFailure(
                    placementId: String?,
                    error: UnityAds.UnityAdsShowError?,
                    message: String?
                ) {
                    val code = error?.name ?: "SHOW_ERROR"
                    val msg = message ?: "Failed to display Interstitial Ad"
                    _rawErrorMessage.value = "Interstitial Show Error [$code]: $msg"
                    coroutineScope.launch {
                        _uiEvents.emit(UiEvent.ShowToast("Ad failed to show: $msg"))
                    }
                    // Silently reload next ad
                    _interstitialStatus.value = AdLoadingStatus.Idle
                    loadInterstitialAd()
                }
            }
        )
    }

    private fun scheduleRetry(isRewarded: Boolean) {
        if (isRewarded) {
            retryRewardedJob?.cancel()
            retryRewardedJob = coroutineScope.launch {
                delay(5000)
                loadRewardedAd()
            }
        } else {
            retryInterstitialJob?.cancel()
            retryInterstitialJob = coroutineScope.launch {
                delay(5000)
                loadInterstitialAd()
            }
        }
    }
}
