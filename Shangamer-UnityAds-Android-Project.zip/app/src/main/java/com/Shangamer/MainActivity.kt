package com.Shangamer

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.Shangamer.ads.UiEvent
import com.Shangamer.ui.MainViewModel
import com.Shangamer.ui.components.AdActionButtons
import com.Shangamer.ui.components.AdPerformanceCard
import com.Shangamer.ui.components.AdsEngineStatusCard
import com.Shangamer.ui.components.CoinBalanceCard
import com.Shangamer.ui.components.CoinBurstEffect
import com.Shangamer.ui.components.DeviceSessionCard
import com.Shangamer.ui.components.HeaderSection
import com.Shangamer.ui.components.NetworkLocationCard
import com.Shangamer.ui.components.ResetStatsDialog
import com.Shangamer.ui.theme.DarkNavyBg
import com.Shangamer.ui.theme.DarkPurpleBg
import com.Shangamer.ui.theme.ShangamerTheme
import com.Shangamer.ui.theme.TextMuted
import com.Shangamer.ui.theme.TextSecondary
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ShangamerTheme {
                val snackbarHostState = remember { SnackbarHostState() }
                var showResetDialog by remember { mutableStateOf(false) }
                var triggerCoinBurst by remember { mutableStateOf(false) }

                // Collect UI Events (Toast, Snackbar, Confetti)
                LaunchedEffect(Unit) {
                    viewModel.uiEvents.collectLatest { event ->
                        when (event) {
                            is UiEvent.ShowToast -> {
                                Toast.makeText(this@MainActivity, event.message, Toast.LENGTH_SHORT).show()
                            }
                            is UiEvent.ShowRewardSnackbar -> {
                                snackbarHostState.showSnackbar(event.message)
                            }
                            is UiEvent.TriggerCoinConfetti -> {
                                triggerCoinBurst = true
                            }
                        }
                    }
                }

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    containerColor = DarkPurpleBg
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(DarkPurpleBg, Color(0xFF140D2B), DarkNavyBg)
                                )
                            )
                    ) {
                        ShangamerMainContent(
                            viewModel = viewModel,
                            onWatchRewardedClick = { viewModel.showRewardedAd(this@MainActivity) },
                            onShowInterstitialClick = { viewModel.showInterstitialAd(this@MainActivity) },
                            onReloadAds = { viewModel.reloadAds() },
                            onResetStatsRequest = { showResetDialog = true }
                        )

                        // Coin Confetti particle burst overlay
                        if (triggerCoinBurst) {
                            CoinBurstEffect(
                                modifier = Modifier.fillMaxSize(),
                                onFinished = { triggerCoinBurst = false }
                            )
                        }

                        // Reset Confirmation Dialog
                        if (showResetDialog) {
                            ResetStatsDialog(
                                onConfirm = { viewModel.resetAllStats() },
                                onDismiss = { showResetDialog = false }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShangamerMainContent(
    viewModel: MainViewModel,
    onWatchRewardedClick: () -> Unit,
    onShowInterstitialClick: () -> Unit,
    onReloadAds: () -> Unit,
    onResetStatsRequest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.adStats.collectAsState()
    val sdkStatus by viewModel.sdkStatus.collectAsState()
    val rewardedStatus by viewModel.rewardedStatus.collectAsState()
    val interstitialStatus by viewModel.interstitialStatus.collectAsState()
    val rawErrorMessage by viewModel.rawErrorMessage.collectAsState()
    val isRewardedPending by viewModel.isRewardedPending.collectAsState()
    val isInterstitialPending by viewModel.isInterstitialPending.collectAsState()
    val locationState by viewModel.networkLocationState.collectAsState()
    val sessionDuration by viewModel.sessionDurationSeconds.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1) Header with prominent Unity SDK version at the top
        HeaderSection()

        // 2) Coin Balance Card
        CoinBalanceCard(coinsBalance = stats.coinsBalance)

        // 3) Ads Action Buttons (Watch Rewarded & Show Interstitial)
        AdActionButtons(
            isRewardedPending = isRewardedPending,
            isInterstitialPending = isInterstitialPending,
            onWatchRewardedClick = onWatchRewardedClick,
            onShowInterstitialClick = onShowInterstitialClick
        )

        // 4) Ads Engine Status Card
        AdsEngineStatusCard(
            sdkStatus = sdkStatus,
            rewardedStatus = rewardedStatus,
            interstitialStatus = interstitialStatus,
            rawErrorMessage = rawErrorMessage,
            onReloadAds = onReloadAds
        )

        // 5) Network & Location Telemetry Card (OkHttp + ipwho.is)
        NetworkLocationCard(
            state = locationState,
            onRefresh = { viewModel.fetchLocation() }
        )

        // 6) Ad Performance & Analytics Card (DataStore backed)
        AdPerformanceCard(stats = stats)

        // 7) Device & Live Session Card
        DeviceSessionCard(
            sessionSeconds = sessionDuration,
            sdkStatus = sdkStatus,
            onResetStatsClick = onResetStatsRequest
        )

        // 8) Footer: Mode badge and package name
        FooterSection()

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun FooterSection() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0x26FFFFFF))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "ID: ${Constants.UNITY_GAME_ID}",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(4.dp)
                    .clip(CircleShape)
                    .background(TextMuted)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = Constants.PACKAGE_NAME,
                color = TextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Unity Ads SDK 4.21.0 • Jetpack Compose • Target SDK 34",
            color = TextMuted.copy(alpha = 0.7f),
            fontSize = 10.sp
        )
    }
}
