# Unity Ads ships its own consumer rules.
