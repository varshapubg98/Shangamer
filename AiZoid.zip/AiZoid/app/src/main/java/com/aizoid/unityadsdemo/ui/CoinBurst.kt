package com.aizoid.unityadsdemo.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private class Particle(
    val angle: Float,
    val speed: Float,
    val radius: Float,
    val color: Color
)

private val burstColors = listOf(
    Color(0xFFFFC83D), Color(0xFFFFE27A), Color(0xFFEC4899),
    Color(0xFF8B5CF6), Color(0xFF06B6D4), Color(0xFF3DDC84)
)

/** Small coin burst / confetti. Increase [trigger] to fire it. */
@Composable
fun CoinBurst(trigger: Int, modifier: Modifier = Modifier) {
    val progress = remember { Animatable(1f) }
    val particles = remember(trigger) {
        List(40) {
            Particle(
                angle = Random.nextFloat() * (2f * PI.toFloat()),
                speed = 200f + Random.nextFloat() * 600f,
                radius = 5f + Random.nextFloat() * 8f,
                color = burstColors.random()
            )
        }
    }

    LaunchedEffect(trigger) {
        if (trigger > 0) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(1500, easing = LinearOutSlowInEasing))
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val p = progress.value
        if (p < 1f) {
            val cx = size.width / 2f
            val cy = size.height * 0.30f
            particles.forEach { part ->
                val dist = part.speed * p
                val x = cx + cos(part.angle) * dist
                val y = cy + sin(part.angle) * dist + 700f * p * p
                drawCircle(
                    color = part.color.copy(alpha = 1f - p),
                    radius = part.radius,
                    center = Offset(x, y)
                )
            }
        }
    }
}
