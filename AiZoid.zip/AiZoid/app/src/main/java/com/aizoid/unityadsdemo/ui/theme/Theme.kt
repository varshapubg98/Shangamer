package com.aizoid.unityadsdemo.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PurpleDeep = Color(0xFF2B1065)
val NavyDark = Color(0xFF080C26)
val Violet = Color(0xFF8B5CF6)
val Gold = Color(0xFFFFC83D)
val GlassBorder = Color(0x29FFFFFF)
val TextPrimary = Color(0xFFF5F2FF)
val TextSecondary = Color(0xFFB4ADD6)
val StatusGreen = Color(0xFF3DDC84)
val StatusAmber = Color(0xFFFFB74D)
val StatusRed = Color(0xFFFF5470)
val StatusBlue = Color(0xFF4DA3FF)
val StatusGray = Color(0xFF8E8AA8)

@Composable
fun AiZoidTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            secondary = Gold,
            background = NavyDark,
            surface = Color(0xFF1B1745),
            onPrimary = Color.White,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        ),
        content = content
    )
}
