package com.aizoid.unityadsdemo.ui

import android.app.Activity
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aizoid.unityadsdemo.AdKind
import com.aizoid.unityadsdemo.MainViewModel
import com.aizoid.unityadsdemo.UiMessage
import com.aizoid.unityadsdemo.ui.theme.NavyDark
import com.aizoid.unityadsdemo.ui.theme.PurpleDeep
import com.aizoid.unityadsdemo.ui.theme.StatusRed
import com.aizoid.unityadsdemo.ui.theme.TextPrimary
import com.aizoid.unityadsdemo.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun MainScreen(viewModel: MainViewModel, activity: Activity) {
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val sdkStatus by viewModel.sdkStatus.collectAsStateWithLifecycle()
    val rewardedState by viewModel.rewardedState.collectAsStateWithLifecycle()
    val interstitialState by viewModel.interstitialState.collectAsStateWithLifecycle()
    val lastError by viewModel.lastError.collectAsStateWithLifecycle()
    val rewardedWaiting by viewModel.rewardedWaiting.collectAsStateWithLifecycle()
    val interstitialWaiting by viewModel.interstitialWaiting.collectAsStateWithLifecycle()
    val netState by viewModel.netState.collectAsStateWithLifecycle()
    val sessionSeconds by viewModel.sessionSeconds.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var burstTrigger by remember { mutableIntStateOf(0) }
    var showResetDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.messages.collect { msg ->
            snackbarHostState.currentSnackbarData?.dismiss()
            when (msg) {
                is UiMessage.Reward -> {
                    burstTrigger++
                    scope.launch {
                        snackbarHostState.showSnackbar(
                            "\uD83C\uDF89 Congratulations! You earned +${msg.coins} coins"
                        )
                    }
                }

                is UiMessage.Info -> scope.launch { snackbarHostState.showSnackbar(msg.text) }
            }
        }
    }

    CompositionLocalProvider(LocalContentColor provides TextPrimary) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(PurpleDeep, NavyDark)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                HeaderSection()
                CoinBalanceCard(coins = stats.coinsEarned)

                RewardedAdButton(isWaiting = rewardedWaiting) {
                    viewModel.onAdButtonClick(activity, AdKind.REWARDED)
                }
                InterstitialAdButton(isWaiting = interstitialWaiting) {
                    viewModel.onAdButtonClick(activity, AdKind.INTERSTITIAL)
                }

                AdsStatusCard(
                    sdkStatus = sdkStatus,
                    rewardedState = rewardedState,
                    interstitialState = interstitialState,
                    lastError = lastError,
                    onReload = viewModel::reloadAds
                )
                NetworkLocationCard(state = netState, onRetry = viewModel::loadNetwork)
                AdPerformanceCard(stats = stats)

                OutlinedButton(
                    onClick = { showResetDialog = true },
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, StatusRed.copy(alpha = 0.7f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Reset Stats")
                }

                DeviceSessionCard(
                    deviceModel = viewModel.deviceModel,
                    androidVersion = viewModel.androidVersion,
                    appVersion = viewModel.appVersion,
                    sessionSeconds = sessionSeconds,
                    sdkStatus = sdkStatus
                )
                FooterSection()
            }

            CoinBurst(trigger = burstTrigger)

            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(16.dp)
            )
        }

        if (showResetDialog) {
            AlertDialog(
                onDismissRequest = { showResetDialog = false },
                containerColor = Color(0xFF1B1745),
                title = { Text("Reset all stats?", color = TextPrimary) },
                text = {
                    Text(
                        "This clears all counters and your coin balance. This cannot be undone.",
                        color = TextSecondary
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.resetStats()
                        showResetDialog = false
                    }) { Text("Reset", color = StatusRed) }
                },
                dismissButton = {
                    TextButton(onClick = { showResetDialog = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }
    }
}
