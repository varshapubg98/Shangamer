package com.aizoid.unityadsdemo

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.adStatsDataStore: DataStore<Preferences> by preferencesDataStore(name = "ad_stats")

enum class StatKey(val key: Preferences.Key<Int>) {
    CLICKS(intPreferencesKey("clicks")),
    IMPRESSIONS(intPreferencesKey("impressions")),
    REWARDED_WATCHED(intPreferencesKey("rewarded_watched")),
    INTERSTITIALS_SHOWN(intPreferencesKey("interstitials_shown")),
    SKIPPED(intPreferencesKey("skipped")),
    COINS(intPreferencesKey("coins")),
    LOAD_SUCCESS(intPreferencesKey("load_success")),
    LOAD_FAILED(intPreferencesKey("load_failed"))
}

data class AdStats(
    val clicks: Int = 0,
    val impressions: Int = 0,
    val rewardedWatched: Int = 0,
    val interstitialsShown: Int = 0,
    val skipped: Int = 0,
    val coinsEarned: Int = 0,
    val loadSuccess: Int = 0,
    val loadFailed: Int = 0
) {
    /** CTR % = clicks / ads shown * 100 */
    val ctr: Float get() = if (impressions > 0) clicks * 100f / impressions else 0f

    /** (impressions / 1000) * eCPM */
    val estimatedEarnings: Double get() = impressions / 1000.0 * ESTIMATED_ECPM_USD
}

class AdStatsRepository(context: Context) {

    private val store = context.applicationContext.adStatsDataStore

    val stats: Flow<AdStats> = store.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { p ->
            AdStats(
                clicks = p[StatKey.CLICKS.key] ?: 0,
                impressions = p[StatKey.IMPRESSIONS.key] ?: 0,
                rewardedWatched = p[StatKey.REWARDED_WATCHED.key] ?: 0,
                interstitialsShown = p[StatKey.INTERSTITIALS_SHOWN.key] ?: 0,
                skipped = p[StatKey.SKIPPED.key] ?: 0,
                coinsEarned = p[StatKey.COINS.key] ?: 0,
                loadSuccess = p[StatKey.LOAD_SUCCESS.key] ?: 0,
                loadFailed = p[StatKey.LOAD_FAILED.key] ?: 0
            )
        }

    suspend fun increment(stat: StatKey, by: Int = 1) {
        store.edit { it[stat.key] = (it[stat.key] ?: 0) + by }
    }

    suspend fun reset() {
        store.edit { it.clear() }
    }
}
