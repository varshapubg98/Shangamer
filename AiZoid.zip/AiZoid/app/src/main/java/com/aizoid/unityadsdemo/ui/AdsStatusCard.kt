package com.aizoid.unityadsdemo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aizoid.unityadsdemo.AdState
import com.aizoid.unityadsdemo.SdkStatus
import com.aizoid.unityadsdemo.ui.components.GlassCard
import com.aizoid.unityadsdemo.ui.components.SectionTitle
import com.aizoid.unityadsdemo.ui.components.StatusDot
import com.aizoid.unityadsdemo.ui.theme.StatusAmber
import com.aizoid.unityadsdemo.ui.theme.StatusBlue
import com.aizoid.unityadsdemo.ui.theme.StatusGray
import com.aizoid.unityadsdemo.ui.theme.StatusGreen
import com.aizoid.unityadsdemo.ui.theme.StatusRed
import com.aizoid.unityadsdemo.ui.theme.TextPrimary
import com.aizoid.unityadsdemo.ui.theme.TextSecondary
import com.aizoid.unityadsdemo.ui.theme.Violet

fun sdkColor(status: SdkStatus): Color = when (status) {
    SdkStatus.READY -> StatusGreen
    SdkStatus.INITIALIZING -> StatusAmber
    SdkStatus.FAILED -> StatusRed
    SdkStatus.NOT_INITIALIZED -> StatusGray
}

fun adColor(state: AdState): Color = when (state) {
    AdState.READY -> StatusGreen
    AdState.LOADING -> StatusAmber
    AdState.FAILED -> StatusRed
    AdState.SHOWING -> StatusBlue
    AdState.IDLE -> StatusGray
}

@Composable
private fun StatusRow(label: String, text: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
        StatusDot(color)
        Spacer(Modifier.width(8.dp))
        Text(text, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun AdsStatusCard(
    sdkStatus: SdkStatus,
    rewardedState: AdState,
    interstitialState: AdState,
    lastError: String?,
    onReload: () -> Unit
) {
    GlassCard {
        SectionTitle("Ads Engine Status", Icons.Rounded.Settings)
        Spacer(Modifier.height(8.dp))
        StatusRow("Unity SDK", sdkStatus.label, sdkColor(sdkStatus))
        StatusRow("Rewarded", rewardedState.label, adColor(rewardedState))
        StatusRow("Interstitial", interstitialState.label, adColor(interstitialState))
        Spacer(Modifier.height(10.dp))

        val boxShape = RoundedCornerShape(12.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(boxShape)
                .background(Color.Black.copy(alpha = 0.25f))
                .border(1.dp, Color.White.copy(alpha = 0.1f), boxShape)
                .padding(12.dp)
        ) {
            Text(
                text = lastError ?: "No errors",
                color = if (lastError != null) StatusRed else TextSecondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onReload,
            colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Color.White),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Reload Ads", fontWeight = FontWeight.Bold)
        }
    }
}
