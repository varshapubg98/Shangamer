package com.aizoid.unityadsdemo.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aizoid.unityadsdemo.PACKAGE_NAME
import com.aizoid.unityadsdemo.TEST_MODE
import com.aizoid.unityadsdemo.ui.components.StatusBadge
import com.aizoid.unityadsdemo.ui.theme.StatusAmber
import com.aizoid.unityadsdemo.ui.theme.StatusGreen
import com.aizoid.unityadsdemo.ui.theme.TextSecondary

@Composable
fun FooterSection() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatusBadge(
            text = if (TEST_MODE) "TEST MODE" else "PRODUCTION MODE",
            color = if (TEST_MODE) StatusAmber else StatusGreen
        )
        Text(PACKAGE_NAME, color = TextSecondary, fontSize = 12.sp)
    }
}
