package com.aizoid.unityadsdemo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MonetizationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aizoid.unityadsdemo.REWARD_COINS_PER_AD
import com.aizoid.unityadsdemo.ui.components.GlassCard
import com.aizoid.unityadsdemo.ui.components.StatusBadge
import com.aizoid.unityadsdemo.ui.components.animInt
import com.aizoid.unityadsdemo.ui.theme.Gold
import com.aizoid.unityadsdemo.ui.theme.TextSecondary

@Composable
fun CoinBalanceCard(coins: Int) {
    val animated = animInt(coins, 1200)
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(listOf(Color(0xFFFFE27A), Gold, Color(0xFFD99A00)))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.MonetizationOn,
                    contentDescription = null,
                    tint = Color(0xFF7A5200),
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Coin Balance", color = TextSecondary, fontSize = 13.sp)
                Text(
                    "%,d".format(animated),
                    color = Gold,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            StatusBadge("+$REWARD_COINS_PER_AD / Ad", Gold)
        }
    }
}
