package com.aizoid.unityadsdemo

import android.app.Activity
import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.lang.ref.WeakReference

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = AdStatsRepository(app)
    private val networkService = NetworkLocationService()
    private val ads = UnityAdsManager(app, viewModelScope, repo)

    // ---- Ads / stats
    val stats: StateFlow<AdStats> =
        repo.stats.stateIn(viewModelScope, SharingStarted.Eagerly, AdStats())
    val sdkStatus: StateFlow<SdkStatus> = ads.sdkStatus
    val rewardedState: StateFlow<AdState> = ads.rewardedState
    val interstitialState: StateFlow<AdState> = ads.interstitialState
    val lastError: StateFlow<String?> = ads.lastError
    val messages: SharedFlow<UiMessage> = ads.messages

    // ---- Pending button taps
    private val _rewardedWaiting = MutableStateFlow(false)
    val rewardedWaiting: StateFlow<Boolean> = _rewardedWaiting.asStateFlow()
    private val _interstitialWaiting = MutableStateFlow(false)
    val interstitialWaiting: StateFlow<Boolean> = _interstitialWaiting.asStateFlow()

    // ---- Session timer
    private val _sessionSeconds = MutableStateFlow(0)
    val sessionSeconds: StateFlow<Int> = _sessionSeconds.asStateFlow()

    // ---- Network
    private val _netState = MutableStateFlow<NetState>(NetState.Loading)
    val netState: StateFlow<NetState> = _netState.asStateFlow()

    // ---- Device info
    val deviceModel: String = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
    val androidVersion: String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
    val appVersion: String = try {
        @Suppress("DEPRECATION")
        app.packageManager.getPackageInfo(app.packageName, 0).versionName ?: "1.0"
    } catch (e: Exception) {
        "1.0"
    }

    init {
        ads.initialize()
        loadNetwork()
        viewModelScope.launch {
            while (true) {
                delay(1_000)
                _sessionSeconds.value += 1
            }
        }
    }

    fun reloadAds() = ads.reloadAll()

    fun loadNetwork() {
        viewModelScope.launch {
            _netState.value = NetState.Loading
            _netState.value = networkService.fetch().fold(
                onSuccess = { NetState.Success(it) },
                onFailure = { NetState.Error(it.message ?: "Unknown error") }
            )
        }
    }

    fun resetStats() {
        viewModelScope.launch { repo.reset() }
    }

    /**
     * The ad only plays because the user tapped the button.
     * READY -> show now. Otherwise wait up to 30s for the load, then show.
     */
    fun onAdButtonClick(activity: Activity, kind: AdKind) {
        val waiting = if (kind == AdKind.REWARDED) _rewardedWaiting else _interstitialWaiting
        if (waiting.value) return // ignore extra taps while pending

        if (ads.show(activity, kind)) return

        waiting.value = true
        val activityRef = WeakReference(activity)
        viewModelScope.launch {
            try {
                ads.ensureLoading(kind)
                val ready = withTimeoutOrNull(30_000L) {
                    ads.adState(kind).first { it == AdState.READY }
                }
                if (ready == null) {
                    ads.postMessage(UiMessage.Info("No ad available right now, please try again"))
                } else {
                    val act = activityRef.get()
                    if (act != null && !act.isFinishing) ads.show(act, kind)
                }
            } finally {
                waiting.value = false
            }
        }
    }
}
