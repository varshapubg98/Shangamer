package com.aizoid.unityadsdemo

const val APP_NAME = "AiZoid"
const val PACKAGE_NAME = "com.aizoid.unityadsdemo"
const val UNITY_GAME_ID = "YOUR_UNITY_GAME_ID_HERE"
const val REWARDED_PLACEMENT_ID = "Rewarded_Android"
const val INTERSTITIAL_PLACEMENT_ID = "Interstitial_Android"
const val TEST_MODE = false
const val ESTIMATED_ECPM_USD = 2.0
const val REWARD_COINS_PER_AD = 10
