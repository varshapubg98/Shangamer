package com.aizoid.unityadsdemo

import android.app.Activity
import android.content.Context
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class UnityAdsManager(
    context: Context,
    private val scope: CoroutineScope,
    private val repo: AdStatsRepository
) {
    private val appContext = context.applicationContext

    private val _sdkStatus = MutableStateFlow(SdkStatus.NOT_INITIALIZED)
    val sdkStatus: StateFlow<SdkStatus> = _sdkStatus.asStateFlow()

    private val _rewardedState = MutableStateFlow(AdState.IDLE)
    val rewardedState: StateFlow<AdState> = _rewardedState.asStateFlow()

    private val _interstitialState = MutableStateFlow(AdState.IDLE)
    val interstitialState: StateFlow<AdState> = _interstitialState.asStateFlow()

    /** Raw error text exactly as returned by the Unity SDK. */
    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 16)
    val messages: SharedFlow<UiMessage> = _messages.asSharedFlow()

    private val retryJobs = mutableMapOf<AdKind, Job>()

    fun adState(kind: AdKind): StateFlow<AdState> =
        if (kind == AdKind.REWARDED) rewardedState else interstitialState

    private fun setState(kind: AdKind, state: AdState) {
        if (kind == AdKind.REWARDED) _rewardedState.value = state else _interstitialState.value = state
    }

    fun postMessage(message: UiMessage) {
        _messages.tryEmit(message)
    }

    // ---------------------------------------------------------------- init

    fun initialize() {
        if (_sdkStatus.value == SdkStatus.INITIALIZING || _sdkStatus.value == SdkStatus.READY) return
        _sdkStatus.value = SdkStatus.INITIALIZING
        UnityAds.initialize(
            appContext,
            UNITY_GAME_ID,
            TEST_MODE,
            object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() {
                    _sdkStatus.value = SdkStatus.READY
                    _lastError.value = null
                    load(AdKind.REWARDED)
                    load(AdKind.INTERSTITIAL)
                }

                override fun onInitializationFailed(
                    error: UnityAds.UnityAdsInitializationError?,
                    message: String?
                ) {
                    _sdkStatus.value = SdkStatus.FAILED
                    _lastError.value = "Init failed\nCode: ${error?.name}\nMessage: $message"
                }
            }
        )
    }

    // ---------------------------------------------------------------- load

    private fun load(kind: AdKind) {
        if (_sdkStatus.value != SdkStatus.READY) return
        retryJobs.remove(kind)?.cancel()
        setState(kind, AdState.LOADING)
        UnityAds.load(kind.placementId, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) {
                setState(kind, AdState.READY)
                _lastError.value = null
                scope.launch { repo.increment(StatKey.LOAD_SUCCESS) }
            }

            override fun onUnityAdsFailedToLoad(
                placementId: String?,
                error: UnityAds.UnityAdsLoadError?,
                message: String?
            ) {
                setState(kind, AdState.FAILED)
                _lastError.value = "Load failed [$placementId]\nCode: ${error?.name}\nMessage: $message"
                scope.launch { repo.increment(StatKey.LOAD_FAILED) }
                // retry after 5 seconds, repeatedly
                retryJobs[kind] = scope.launch {
                    delay(5_000)
                    retryJobs.remove(kind)
                    load(kind)
                }
            }
        })
    }

    /** Reload button: re-init if needed, otherwise reload both ads. */
    fun reloadAll() {
        if (_sdkStatus.value == SdkStatus.FAILED || _sdkStatus.value == SdkStatus.NOT_INITIALIZED) {
            initialize()
            return
        }
        if (_sdkStatus.value != SdkStatus.READY) return
        if (_rewardedState.value != AdState.SHOWING) load(AdKind.REWARDED)
        if (_interstitialState.value != AdState.SHOWING) load(AdKind.INTERSTITIAL)
    }

    /** Called before waiting on a pending tap, so we never wait on a dead state. */
    fun ensureLoading(kind: AdKind) {
        when (_sdkStatus.value) {
            SdkStatus.FAILED, SdkStatus.NOT_INITIALIZED -> initialize()
            SdkStatus.READY -> if (adState(kind).value == AdState.IDLE) load(kind)
            SdkStatus.INITIALIZING -> Unit
        }
    }

    // ---------------------------------------------------------------- show

    /** Shows the ad immediately if READY. Returns true if show was started. */
    fun show(activity: Activity, kind: AdKind): Boolean {
        if (adState(kind).value != AdState.READY) return false
        setState(kind, AdState.SHOWING)
        UnityAds.show(
            activity,
            kind.placementId,
            UnityAdsShowOptions(),
            object : IUnityAdsShowListener {
                override fun onUnityAdsShowStart(placementId: String?) {
                    scope.launch { repo.increment(StatKey.IMPRESSIONS) }
                }

                override fun onUnityAdsShowClick(placementId: String?) {
                    scope.launch { repo.increment(StatKey.CLICKS) }
                }

                override fun onUnityAdsShowComplete(
                    placementId: String?,
                    state: UnityAds.UnityAdsShowCompletionState?
                ) {
                    val completed = state == UnityAds.UnityAdsShowCompletionState.COMPLETED
                    scope.launch {
                        if (kind == AdKind.REWARDED) {
                            if (completed) {
                                repo.increment(StatKey.REWARDED_WATCHED)
                                repo.increment(StatKey.COINS, REWARD_COINS_PER_AD)
                                postMessage(UiMessage.Reward(REWARD_COINS_PER_AD))
                            } else {
                                repo.increment(StatKey.SKIPPED)
                                postMessage(UiMessage.Info("Ad skipped - no reward"))
                            }
                        } else {
                            repo.increment(StatKey.INTERSTITIALS_SHOWN)
                            if (!completed) repo.increment(StatKey.SKIPPED)
                        }
                    }
                    afterShow(kind)
                }

                override fun onUnityAdsShowFailure(
                    placementId: String?,
                    error: UnityAds.UnityAdsShowError?,
                    message: String?
                ) {
                    _lastError.value = "Show failed [$placementId]\nCode: ${error?.name}\nMessage: $message"
                    afterShow(kind)
                }
            }
        )
        return true
    }

    /** After every show (success or failure), silently load the next ad. */
    private fun afterShow(kind: AdKind) {
        setState(kind, AdState.IDLE)
        load(kind)
    }
}
