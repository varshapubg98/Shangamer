package com.aizoid.unityadsdemo.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aizoid.unityadsdemo.REWARD_COINS_PER_AD
import kotlinx.coroutines.delay

enum class IconMotion { WIGGLE, BOUNCE }

@Composable
fun RewardedAdButton(isWaiting: Boolean, onClick: () -> Unit) {
    AdActionButton(
        label = "Watch Rewarded Ad (+$REWARD_COINS_PER_AD Coins)",
        icon = Icons.Rounded.CardGiftcard,
        isWaiting = isWaiting,
        gradient = listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)),
        glowColor = Color(0xFFEC4899),
        motion = IconMotion.WIGGLE,
        onClick = onClick
    )
}

@Composable
fun InterstitialAdButton(isWaiting: Boolean, onClick: () -> Unit) {
    AdActionButton(
        label = "Show Interstitial Ad",
        icon = Icons.Rounded.Tv,
        isWaiting = isWaiting,
        gradient = listOf(Color(0xFF2563EB), Color(0xFF06B6D4)),
        glowColor = Color(0xFF06B6D4),
        motion = IconMotion.BOUNCE,
        onClick = onClick
    )
}

/** Always looks active; never disabled. */
@Composable
fun AdActionButton(
    label: String,
    icon: ImageVector,
    isWaiting: Boolean,
    gradient: List<Color>,
    glowColor: Color,
    motion: IconMotion,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "pressScale"
    )

    val infinite = rememberInfiniteTransition(label = "idle")
    val glow by infinite.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    val shimmerX by infinite.animateFloat(
        initialValue = -400f,
        targetValue = 1200f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmerX"
    )

    val iconAnim = remember { Animatable(0f) }
    LaunchedEffect(motion) {
        while (true) {
            delay(if (motion == IconMotion.WIGGLE) 3000L else 3500L)
            if (motion == IconMotion.WIGGLE) {
                repeat(3) {
                    iconAnim.animateTo(18f, tween(70))
                    iconAnim.animateTo(-18f, tween(70))
                }
                iconAnim.animateTo(0f, tween(70))
            } else {
                iconAnim.animateTo(-14f, tween(160, easing = FastOutSlowInEasing))
                iconAnim.animateTo(
                    0f,
                    spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessLow)
                )
            }
        }
    }

    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(66.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = 14.dp,
                shape = shape,
                ambientColor = glowColor.copy(alpha = glow),
                spotColor = glowColor.copy(alpha = glow)
            )
            .clip(shape)
            .background(Brush.horizontalGradient(gradient))
            .drawWithContent {
                drawContent()
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.28f), Color.Transparent),
                        start = Offset(shimmerX, 0f),
                        end = Offset(shimmerX + 250f, size.height)
                    )
                )
            }
            .border(1.5.dp, glowColor.copy(alpha = glow), shape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isWaiting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = Color.White,
                    strokeWidth = 2.5.dp
                )
                Spacer(Modifier.width(12.dp))
                Text("Loading ad...", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            } else {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier
                        .size(28.dp)
                        .graphicsLayer {
                            if (motion == IconMotion.WIGGLE) {
                                rotationZ = iconAnim.value
                            } else {
                                translationY = iconAnim.value * density
                            }
                        }
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    label,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
