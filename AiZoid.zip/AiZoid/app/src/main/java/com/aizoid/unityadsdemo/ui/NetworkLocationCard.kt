package com.aizoid.unityadsdemo.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aizoid.unityadsdemo.NetState
import com.aizoid.unityadsdemo.ui.components.GlassCard
import com.aizoid.unityadsdemo.ui.components.InfoRow
import com.aizoid.unityadsdemo.ui.components.SectionTitle
import com.aizoid.unityadsdemo.ui.components.shimmer
import com.aizoid.unityadsdemo.ui.theme.StatusRed
import com.aizoid.unityadsdemo.ui.theme.TextSecondary
import com.aizoid.unityadsdemo.ui.theme.Violet

@Composable
fun NetworkLocationCard(state: NetState, onRetry: () -> Unit) {
    GlassCard {
        SectionTitle("Network & Location", Icons.Rounded.Public) {
            IconButton(onClick = onRetry) {
                Icon(Icons.Rounded.Refresh, contentDescription = "Refresh", tint = TextSecondary)
            }
        }
        Spacer(Modifier.height(6.dp))
        when (state) {
            is NetState.Loading -> {
                repeat(6) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(18.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .shimmer()
                    )
                    Spacer(Modifier.height(12.dp))
                }
            }

            is NetState.Error -> {
                Column {
                    Text(
                        "Could not load network info: ${state.message}",
                        color = StatusRed,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Color.White),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Retry", fontWeight = FontWeight.Bold)
                    }
                }
            }

            is NetState.Success -> {
                val i = state.info
                InfoRow("Country", "${i.flag} ${i.country}")
                InfoRow("State / Region", i.region)
                InfoRow("City", i.city)
                InfoRow("IP Address", i.ip)
                InfoRow("ISP", i.isp)
                InfoRow("Timezone", i.timezone)
            }
        }
    }
}
