package com.aizoid.unityadsdemo.ui

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aizoid.unityadsdemo.SdkStatus
import com.aizoid.unityadsdemo.TEST_MODE
import com.aizoid.unityadsdemo.ui.components.GlassCard
import com.aizoid.unityadsdemo.ui.components.InfoRow
import com.aizoid.unityadsdemo.ui.components.SectionTitle
import com.aizoid.unityadsdemo.ui.components.StatusBadge
import com.aizoid.unityadsdemo.ui.components.StatusDot
import com.aizoid.unityadsdemo.ui.theme.StatusAmber
import com.aizoid.unityadsdemo.ui.theme.StatusGreen
import com.aizoid.unityadsdemo.ui.theme.TextPrimary
import com.aizoid.unityadsdemo.ui.theme.TextSecondary

@Composable
fun DeviceSessionCard(
    deviceModel: String,
    androidVersion: String,
    appVersion: String,
    sessionSeconds: Int,
    sdkStatus: SdkStatus
) {
    GlassCard {
        SectionTitle("Device & Session", Icons.Rounded.PhoneAndroid)
        Spacer(Modifier.height(6.dp))
        InfoRow("Device", deviceModel)
        InfoRow("Android", androidVersion)
        InfoRow("App Version", appVersion)
        InfoRow("Session", "%02d:%02d".format(sessionSeconds / 60, sessionSeconds % 60))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SDK Status", color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
            StatusDot(sdkColor(sdkStatus))
            Spacer(Modifier.width(8.dp))
            Text(sdkStatus.label, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Mode", color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
            StatusBadge(
                text = if (TEST_MODE) "TEST" else "PRODUCTION",
                color = if (TEST_MODE) StatusAmber else StatusGreen
            )
        }
    }
}
