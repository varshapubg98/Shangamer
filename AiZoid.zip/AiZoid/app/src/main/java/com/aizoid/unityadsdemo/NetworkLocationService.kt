package com.aizoid.unityadsdemo

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class NetworkInfo(
    val country: String,
    val flag: String,
    val region: String,
    val city: String,
    val ip: String,
    val isp: String,
    val timezone: String
)

class NetworkLocationService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
) {

    /** Real data from https://ipwho.is/ — runs on a background dispatcher. */
    suspend fun fetch(): Result<NetworkInfo> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("https://ipwho.is/")
                .header("Accept", "application/json")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IOException("HTTP ${response.code}"))
                }
                val body = response.body?.string().orEmpty()
                val json = JSONObject(body)
                if (!json.optBoolean("success", false)) {
                    return@withContext Result.failure(
                        IOException(json.optString("message", "Lookup failed"))
                    )
                }
                val info = NetworkInfo(
                    country = json.optString("country", "Unknown"),
                    flag = flagEmoji(json.optString("country_code", "")),
                    region = json.optString("region", "Unknown"),
                    city = json.optString("city", "Unknown"),
                    ip = json.optString("ip", "Unknown"),
                    isp = json.optJSONObject("connection")?.optString("isp", "Unknown") ?: "Unknown",
                    timezone = json.optJSONObject("timezone")?.optString("id", "Unknown") ?: "Unknown"
                )
                Result.success(info)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun flagEmoji(code: String): String {
        if (code.length != 2) return "\uD83C\uDF10"
        val upper = code.uppercase()
        val first = Character.codePointAt(upper, 0) - 0x41 + 0x1F1E6
        val second = Character.codePointAt(upper, 1) - 0x41 + 0x1F1E6
        return String(Character.toChars(first)) + String(Character.toChars(second))
    }
}
