package com.aizoid.unityadsdemo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AttachMoney
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.MonetizationOn
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aizoid.unityadsdemo.AdStats
import com.aizoid.unityadsdemo.ui.components.GlassCard
import com.aizoid.unityadsdemo.ui.components.SectionTitle
import com.aizoid.unityadsdemo.ui.components.animFloat
import com.aizoid.unityadsdemo.ui.components.animInt

@Composable
private fun StatTile(
    title: String,
    value: String,
    icon: ImageVector,
    colors: List<Color>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(colors))
            .padding(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(10.dp))
        Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(title, color = Color.White.copy(alpha = 0.88f), fontSize = 12.sp)
    }
}

@Composable
private fun TileRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) { content() }
}

@Composable
fun AdPerformanceCard(stats: AdStats) {
    val clicks = animInt(stats.clicks)
    val ctr = animFloat(stats.ctr)
    val rewarded = animInt(stats.rewardedWatched)
    val inter = animInt(stats.interstitialsShown)
    val skipped = animInt(stats.skipped)
    val coins = animInt(stats.coinsEarned)
    val loadOk = animInt(stats.loadSuccess)
    val loadFail = animInt(stats.loadFailed)
    val earnings = animFloat(stats.estimatedEarnings.toFloat())

    GlassCard {
        SectionTitle("Ad Performance", Icons.Rounded.BarChart)
        Spacer(Modifier.height(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            TileRow {
                StatTile("Total Ad Clicks", "$clicks", Icons.Rounded.TouchApp,
                    listOf(Color(0xFF7C3AED), Color(0xFF4F46E5)), Modifier.weight(1f).fillMaxHeight())
                StatTile("CTR %", "%.1f%%".format(ctr), Icons.Rounded.Insights,
                    listOf(Color(0xFF0EA5E9), Color(0xFF2563EB)), Modifier.weight(1f).fillMaxHeight())
            }
            TileRow {
                StatTile("Rewarded Watched", "$rewarded", Icons.Rounded.CardGiftcard,
                    listOf(Color(0xFFEC4899), Color(0xFF9333EA)), Modifier.weight(1f).fillMaxHeight())
                StatTile("Interstitials Shown", "$inter", Icons.Rounded.Tv,
                    listOf(Color(0xFF06B6D4), Color(0xFF0E7490)), Modifier.weight(1f).fillMaxHeight())
            }
            TileRow {
                StatTile("Ads Skipped", "$skipped", Icons.Rounded.SkipNext,
                    listOf(Color(0xFFF59E0B), Color(0xFFD97706)), Modifier.weight(1f).fillMaxHeight())
                StatTile("Total Coins Earned", "$coins", Icons.Rounded.MonetizationOn,
                    listOf(Color(0xFFEAB308), Color(0xFFB45309)), Modifier.weight(1f).fillMaxHeight())
            }
            TileRow {
                StatTile("Load Success", "$loadOk", Icons.Rounded.CheckCircle,
                    listOf(Color(0xFF10B981), Color(0xFF047857)), Modifier.weight(1f).fillMaxHeight())
                StatTile("Load Failed", "$loadFail", Icons.Rounded.Error,
                    listOf(Color(0xFFF43F5E), Color(0xFFBE123C)), Modifier.weight(1f).fillMaxHeight())
            }
            StatTile(
                title = "Estimated (check Unity Dashboard for real earnings)",
                value = "$" + "%.4f".format(earnings),
                icon = Icons.Rounded.AttachMoney,
                colors = listOf(Color(0xFF22C55E), Color(0xFF0F766E)),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
