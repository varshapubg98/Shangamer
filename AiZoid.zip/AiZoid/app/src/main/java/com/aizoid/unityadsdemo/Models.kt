package com.aizoid.unityadsdemo

enum class SdkStatus(val label: String) {
    NOT_INITIALIZED("Not initialized"),
    INITIALIZING("Initializing"),
    READY("Ready"),
    FAILED("Failed")
}

enum class AdState(val label: String) {
    IDLE("Idle"),
    LOADING("Loading"),
    READY("Ready"),
    SHOWING("Showing"),
    FAILED("Failed")
}

enum class AdKind(val placementId: String) {
    REWARDED(REWARDED_PLACEMENT_ID),
    INTERSTITIAL(INTERSTITIAL_PLACEMENT_ID)
}

sealed interface UiMessage {
    data class Reward(val coins: Int) : UiMessage
    data class Info(val text: String) : UiMessage
}

sealed interface NetState {
    object Loading : NetState
    data class Success(val info: NetworkInfo) : NetState
    data class Error(val message: String) : NetState
}
